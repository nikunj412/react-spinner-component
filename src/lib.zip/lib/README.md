# simple-component-library
A library of React components created using `npx create-react-app`.
## Installation
Run the following command:
`npm install react-spinner-component`